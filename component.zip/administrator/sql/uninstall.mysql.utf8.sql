DROP TABLE IF EXISTS `#__events_main`;
